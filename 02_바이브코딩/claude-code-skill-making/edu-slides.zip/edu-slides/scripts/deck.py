# -*- coding: utf-8 -*-
"""교육용 16:9 슬라이드 디자인 시스템 (python-pptx).

디자인 지침(reference/design-spec.md)을 코드로 고정한 모듈.
좌표 단위는 전부 px(1280x720 기준). 슬라이드 크기 13.333in x 7.5in 은 96dpi에서 1280x720px 이므로
px 값이 화면 픽셀과 1:1 대응한다. 1px = 0.75pt.
"""
from __future__ import annotations

import os
import re

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Pt

A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"

# ---------------------------------------------------------------- 팔레트
PRIMARY = "2563EB"
PRIMARY_DARK = "1D4ED8"
NAVY = "1E3A5F"
HEADING = "1A1A2E"
BODY = "4A4A68"
MUTED = "8A8FA8"
CARD_BLUE = "EFF6FF"
CARD_GRAY = "F4F5F7"
ICON_BG = "DBEAFE"
BORDER = "E2E8F0"
WHITE = "FFFFFF"
WARN_BG = "FEF6E0"
WARN = "F2B705"
DANGER_BG = "FDEDED"
DANGER = "E5484D"

# ---------------------------------------------------------------- 레이아웃
W, H = 1280, 720
TOPBAR_H = 38          # 상단 네이비 바
BOTBAR_H = 7           # 하단 블루 바
MX = 84                # 좌우 여백 (6.5%)
CW = W - MX * 2        # 본문 폭 1112
EYEBROW_Y = 92
TITLE_Y = 118
BODY_TOP = 210         # 타이틀 아래 본문 시작
BODY_BOTTOM = 650      # 본문이 넘지 않는 아래 한계 (페이지 번호 위)
PAGENO_Y = 672
CARD_RADIUS = 18
CALLOUT_MAX_W = 880    # 우측 하단 페이지 번호와 겹치지 않도록 폭 제한

ICON_FONT = "Segoe UI Symbol"   # 체크/경고/자물쇠 글리프용 (Windows 기본 단색)

_FONT_CANDIDATES = [
    ("Pretendard", ("pretendard",)),
    ("Malgun Gothic", ("malgun.ttf",)),
    ("Noto Sans KR", ("notosanskr",)),
]


def resolve_font(preferred=None):
    """설치된 폰트 중 지침에 맞는 것을 고른다. preferred 가 주어지면 그대로 쓴다."""
    if preferred:
        return preferred
    dirs = [
        os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Fonts"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
    ]
    names = []
    for d in dirs:
        try:
            names += [n.lower() for n in os.listdir(d)]
        except OSError:
            pass
    for family, prefixes in _FONT_CANDIDATES:
        for p in prefixes:
            if any(n.startswith(p) for n in names):
                return family
    return "Malgun Gothic"


# ---------------------------------------------------------------- 유틸
def px(v):
    return Emu(int(round(v * 9525)))


def center_y(block_h):
    """본문 블록을 BODY_TOP~BODY_BOTTOM 안에서 세로 가운데에 둔다.

    위아래 여백이 같아야 '여백을 남긴 것'으로 보인다. 위로 쏠리면 아래가 비어 보인다.
    """
    return BODY_TOP + (BODY_BOTTOM - BODY_TOP - block_h) / 2.0


def _rgb(hexstr):
    return RGBColor.from_string(hexstr)


def _no_shadow(shape):
    """지침: 그림자 대신 얇은 테두리.

    빈 <a:effectLst/> 만으로는 부족하다. 도형에 딸려오는 <p:style> 의 effectRef 가
    테마 그림자를 다시 끌어오므로 style 자체를 떼어낸다. (색·폰트는 전부 명시 지정하므로 안전)
    """
    try:
        shape.shadow.inherit = False
    except Exception:
        pass
    el = shape._element
    for st in el.findall("{http://schemas.openxmlformats.org/presentationml/2006/main}style"):
        el.remove(st)


def set_run(run, size, bold=False, color=BODY, font="Malgun Gothic", spacing=None):
    """run 에 서체 적용. latin 뿐 아니라 ea/cs 도 지정해야 한글이 같은 폰트로 나온다."""
    f = run.font
    f.size = Pt(size)
    f.bold = bold
    f.name = font
    f.color.rgb = _rgb(color)
    rPr = run._r.get_or_add_rPr()
    for tag in ("ea", "cs"):
        for old in rPr.findall("{%s}%s" % (A_NS, tag)):
            rPr.remove(old)
        el = etree.SubElement(rPr, "{%s}%s" % (A_NS, tag))
        el.set("typeface", font)
    if spacing:  # 자간 (pt)
        rPr.set("spc", str(int(spacing * 100)))


_RICH = re.compile(r"(\*\*.+?\*\*|!!.+?!!)")


def parse_rich(text):
    """`**강조**` -> 굵게+블루, `!!경고!!` -> 굵게+빨강. 그 외는 기본 스타일."""
    out = []
    for chunk in _RICH.split(text):
        if not chunk:
            continue
        if chunk.startswith("**") and chunk.endswith("**"):
            out.append((chunk[2:-2], "accent"))
        elif chunk.startswith("!!") and chunk.endswith("!!"):
            out.append((chunk[2:-2], "danger"))
        else:
            out.append((chunk, None))
    return out


# ---------------------------------------------------------------- 도형
def add_rect(slide, x, y, w, h, fill=None, line=None, radius=None, line_w=1.0):
    shape_type = MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE
    sh = slide.shapes.add_shape(shape_type, px(x), px(y), px(w), px(h))
    if radius:
        # roundRect 의 adj 값은 '짧은 변 길이에 대한 비율'
        sh.adjustments[0] = min(0.5, radius / float(min(w, h)))
    if fill:
        sh.fill.solid()
        sh.fill.fore_color.rgb = _rgb(fill)
    else:
        sh.fill.background()
    if line:
        sh.line.color.rgb = _rgb(line)
        sh.line.width = Pt(line_w)
    else:
        sh.line.fill.background()
    _no_shadow(sh)
    sh.text_frame.word_wrap = True
    return sh


def add_circle(slide, cx, cy, d, fill=ICON_BG):
    sh = slide.shapes.add_shape(MSO_SHAPE.OVAL, px(cx - d / 2.0), px(cy - d / 2.0), px(d), px(d))
    sh.fill.solid()
    sh.fill.fore_color.rgb = _rgb(fill)
    sh.line.fill.background()
    _no_shadow(sh)
    return sh


def add_text(slide, x, y, w, h, lines,
             size=15, bold=False, color=BODY, font="Malgun Gothic",
             align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line_spacing=1.45,
             space_after=0, accent=PRIMARY, spacing=None):
    """lines: str 또는 str 리스트. 각 줄에 `**강조**` 마크업 사용 가능."""
    if isinstance(lines, str):
        lines = [lines]
    tb = slide.shapes.add_textbox(px(x), px(y), px(w), px(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anchor
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line_spacing
        if space_after:
            p.space_after = Pt(space_after)
        for chunk, style in parse_rich(line):
            r = p.add_run()
            r.text = chunk
            if style == "accent":
                set_run(r, size, True, accent, font, spacing)
            elif style == "danger":
                set_run(r, size, True, DANGER, font, spacing)
            else:
                set_run(r, size, bold, color, font, spacing)
    return tb


def add_glyph(slide, cx, cy, glyph, size=24, color=PRIMARY, box=64):
    """아이콘 원 안의 글리프. 원과 별개 텍스트박스로 올려 세로 중앙을 맞춘다."""
    tb = slide.shapes.add_textbox(px(cx - box / 2.0), px(cy - box / 2.0), px(box), px(box))
    tf = tb.text_frame
    tf.word_wrap = False
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    p.line_spacing = 1.0
    r = p.add_run()
    r.text = glyph
    set_run(r, size, False, color, ICON_FONT)
    return tb


# ---------------------------------------------------------------- Deck
class Deck:
    """슬라이드를 쌓고 마지막에 페이지 번호를 채워 저장한다."""

    def __init__(self, series, lecture="", font=None):
        self.series = series
        self.lecture = lecture
        self.font = resolve_font(font)
        self.prs = Presentation()
        self.prs.slide_width = px(W)
        self.prs.slide_height = px(H)
        self._blank = self.prs.slide_layouts[6]
        self.slides = []

    # ---- 공통 요소 — 모든 슬라이드에 자동 적용
    def new_slide(self):
        s = self.prs.slides.add_slide(self._blank)
        bg = s.background.fill
        bg.solid()
        bg.fore_color.rgb = _rgb(WHITE)
        add_rect(s, 0, 0, W, TOPBAR_H, fill=NAVY)
        add_rect(s, 0, H - BOTBAR_H, W, BOTBAR_H, fill=PRIMARY)
        tb = s.shapes.add_textbox(px(MX), px(0), px(CW), px(TOPBAR_H))
        tf = tb.text_frame
        tf.word_wrap = False
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.line_spacing = 1.0
        r = p.add_run()
        r.text = self.series
        set_run(r, 13, True, WHITE, self.font)
        if self.lecture:
            r2 = p.add_run()
            r2.text = "   |   " + self.lecture
            set_run(r2, 13, False, "C7D2E4", self.font)
        self.slides.append(s)
        return s

    # ---- 머리말 (eyebrow + 타이틀)
    def head(self, s, eyebrow, title, accent=PRIMARY):
        if eyebrow:
            add_text(s, MX, EYEBROW_Y, CW, 20, eyebrow.upper(),
                     size=13, bold=True, color=PRIMARY, font=self.font,
                     line_spacing=1.0, spacing=1.4)
        add_text(s, MX, TITLE_Y, CW, 56, title,
                 size=32, bold=True, color=HEADING, font=self.font,
                 line_spacing=1.2, accent=accent)

    # ---- 카드 한 장 (아이콘 원 + 소제목 + 불릿)
    def card(self, s, x, y, w, h, glyph=None, heading=None, lines=None,
             fill=CARD_BLUE, accent=PRIMARY, icon_bg=ICON_BG):
        add_rect(s, x, y, w, h, fill=fill, line=BORDER, radius=CARD_RADIUS)
        pad = 32
        ty = y + pad
        if glyph:
            add_circle(s, x + pad + 32, y + pad + 32, 64, fill=icon_bg)
            add_glyph(s, x + pad + 32, y + pad + 32, glyph, size=26, color=accent)
            ty = y + pad + 64 + 22
        if heading:
            add_text(s, x + pad, ty, w - pad * 2, 28, heading,
                     size=19, bold=True, color=HEADING, font=self.font,
                     line_spacing=1.2, accent=accent)
            ty += 38
        if lines:
            add_text(s, x + pad, ty, w - pad * 2, y + h - ty - pad,
                     ["\u2022  " + l for l in lines],
                     size=15, color=BODY, font=self.font,
                     line_spacing=1.45, space_after=9, accent=accent)

    # ---- 하단 콜아웃
    def callout(self, s, text, kind="tip", y=592, w=CALLOUT_MAX_W):
        bg, fg, glyph = {
            "tip": (CARD_BLUE, PRIMARY, "\u2713"),
            "warn": (WARN_BG, WARN, "\u26a0"),
            "danger": (DANGER_BG, DANGER, "\U0001F512"),
        }[kind]
        h = 62
        w = min(w, CALLOUT_MAX_W)
        add_rect(s, MX, y, w, h, fill=bg, line=BORDER, radius=14)
        add_glyph(s, MX + 34, y + h / 2.0, glyph, size=20, color=fg, box=40)
        add_text(s, MX + 62, y, w - 62 - 24, h, text,
                 size=15, color=BODY, font=self.font, anchor=MSO_ANCHOR.MIDDLE,
                 line_spacing=1.3, accent=PRIMARY if kind == "tip" else fg)

    # ---- 저장 (페이지 번호는 전체 장수를 안 뒤에 찍는다)
    def save(self, path):
        total = len(self.slides)
        for i, s in enumerate(self.slides, start=1):
            add_text(s, W - MX - 200, PAGENO_Y, 200, 22, "%d / %d" % (i, total),
                     size=11, color=MUTED, font=self.font,
                     align=PP_ALIGN.RIGHT, line_spacing=1.0)
        self.prs.save(path)
        return path


# ---------------------------------------------------------------- 템플릿
def cover(d, title, subtitle="", accent_word=None):
    s = d.new_slide()
    add_rect(s, MX, 250, 72, 8, fill=PRIMARY)     # 강조 바
    t = title
    if accent_word and accent_word in title:
        t = title.replace(accent_word, "**%s**" % accent_word, 1)
    add_text(s, MX, 288, CW, 120, t,
             size=46, bold=True, color=HEADING, font=d.font, line_spacing=1.25)
    if subtitle:
        add_text(s, MX, 428, CW, 40, subtitle,
                 size=17, color=MUTED, font=d.font, line_spacing=1.4)
    return s


def two_col(d, eyebrow, title, left, right):
    """left/right: {glyph, heading, lines}. 좌=연블루(핵심), 우=연회색(부가)."""
    s = d.new_slide()
    d.head(s, eyebrow, title)
    gap = 32
    w = (CW - gap) / 2.0
    h = 356
    y = center_y(h)
    d.card(s, MX, y, w, h, fill=CARD_BLUE, **left)
    d.card(s, MX + w + gap, y, w, h, fill=CARD_GRAY, **right)
    return s


def terms(d, title, items, eyebrow="KEY TERMS"):
    """items: [{glyph, term, define, analogy}] 2개."""
    s = d.new_slide()
    d.head(s, eyebrow, title)
    gap = 32
    w = (CW - gap) / 2.0
    h = 356
    y = center_y(h)
    for i, it in enumerate(items[:2]):
        x = MX + i * (w + gap)
        add_rect(s, x, y, w, h, fill=CARD_BLUE if i == 0 else CARD_GRAY,
                 line=BORDER, radius=CARD_RADIUS)
        pad = 32
        add_circle(s, x + pad + 32, y + pad + 32, 64, fill=ICON_BG)
        add_glyph(s, x + pad + 32, y + pad + 32, it.get("glyph", "\u25c6"), size=26, color=PRIMARY)
        add_text(s, x + pad, y + pad + 84, w - pad * 2, 30, it["term"],
                 size=20, bold=True, color=PRIMARY, font=d.font, line_spacing=1.2)
        add_text(s, x + pad, y + pad + 122, w - pad * 2, 66, it["define"],
                 size=15, color=BODY, font=d.font, line_spacing=1.45)
        if it.get("analogy"):
            add_rect(s, x + pad, y + h - pad - 76, w - pad * 2, 76,
                     fill=WHITE, line=BORDER, radius=12)
            add_text(s, x + pad + 18, y + h - pad - 76, w - pad * 2 - 36, 76,
                     it["analogy"], size=14, color=MUTED, font=d.font,
                     anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.35)
    return s


def step_overview(d, title, steps, current=None, eyebrow="OVERVIEW"):
    """steps: ['단계명', ...] 최대 4개. current: 1-based 강조 인덱스."""
    s = d.new_slide()
    d.head(s, eyebrow, title)
    n = min(len(steps), 4)
    arrow = 44
    bw = (CW - arrow * (n - 1)) / float(n)
    h = 182
    y = center_y(h)
    for i in range(n):
        x = MX + i * (bw + arrow)
        active = (current == i + 1)
        add_rect(s, x, y, bw, h,
                 fill=CARD_BLUE if active else CARD_GRAY,
                 line=PRIMARY if active else BORDER,
                 radius=CARD_RADIUS, line_w=1.75 if active else 1.0)
        add_text(s, x, y + 26, bw, 34, "%02d" % (i + 1),
                 size=26, bold=True, color=PRIMARY if active else MUTED,
                 font=d.font, align=PP_ALIGN.CENTER, line_spacing=1.0)
        add_text(s, x + 16, y + 76, bw - 32, 70, steps[i],
                 size=16, bold=True, color=HEADING if active else BODY,
                 font=d.font, align=PP_ALIGN.CENTER, line_spacing=1.35)
        if i < n - 1:
            add_text(s, x + bw, y + h / 2.0 - 20, arrow, 40, "\u2192",
                     size=22, bold=True, color=PRIMARY, font=d.font,
                     align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.0)
    return s


def step_detail(d, step_no, title, items, callout=None, callout_kind="tip"):
    """items: ['한 줄 설명', ...] 2~3개. 번호 배지 리스트."""
    s = d.new_slide()
    d.head(s, "STEP %s" % step_no, title)
    row_h = 100
    items = items[:3]
    block = row_h * len(items) + (108 if callout else 0)
    y = center_y(block)
    for i, it in enumerate(items):
        cy = y + i * row_h + 34
        add_circle(s, MX + 24, cy, 48, fill=ICON_BG)
        add_text(s, MX, cy - 24, 48, 48, str(i + 1),
                 size=19, bold=True, color=PRIMARY, font=d.font,
                 align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.0)
        add_text(s, MX + 76, cy - 34, CW - 76 - 40, 68, it,
                 size=16, color=BODY, font=d.font,
                 anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.45)
    if callout:
        d.callout(s, callout, kind=callout_kind, y=y + row_h * len(items) + 46)
    return s


def checklist(d, title, items, banner=None, banner_kind="danger", eyebrow="CHECKLIST"):
    """items: [{glyph, heading, text}] 4개 (2x2)."""
    s = d.new_slide()
    d.head(s, eyebrow, title)
    gap = 28
    w = (CW - gap) / 2.0
    h = 136
    rows = 1 if len(items) <= 2 else 2
    block = h * rows + gap * (rows - 1) + (84 if banner else 0)
    y = center_y(block)
    if banner:
        d.callout(s, banner, kind=banner_kind, y=y)
        y += 84
    for i, it in enumerate(items[:4]):
        cx = MX + (i % 2) * (w + gap)
        cy = y + (i // 2) * (h + gap)
        add_rect(s, cx, cy, w, h, fill=CARD_GRAY, line=BORDER, radius=CARD_RADIUS)
        add_circle(s, cx + 48, cy + h / 2.0 - 18, 44, fill=ICON_BG)
        add_glyph(s, cx + 48, cy + h / 2.0 - 18, it.get("glyph", "\u2713"),
                  size=19, color=PRIMARY, box=44)
        tx = cx + 90
        tw = w - 90 - 26
        add_text(s, tx, cy + 28, tw, 26, it["heading"],
                 size=18, bold=True, color=HEADING, font=d.font, line_spacing=1.2)
        add_text(s, tx, cy + 62, tw, 54, it["text"],
                 size=14, color=BODY, font=d.font, line_spacing=1.4)
    return s


def preview(d, title, blocks, filename="index.html", rows=5, eyebrow="PREVIEW"):
    """좌측 브라우저 목업 + 우측 3블록 설명."""
    s = d.new_slide()
    d.head(s, eyebrow, title)
    bw, bh = 600, 352
    bx, by = MX, center_y(bh)
    add_rect(s, bx, by, bw, bh, fill=WHITE, line=BORDER, radius=14)
    add_rect(s, bx, by, bw, 40, fill=CARD_GRAY, line=BORDER, radius=14)
    for i, c in enumerate(("E5484D", "F2B705", "3FB950")):
        add_circle(s, bx + 26 + i * 20, by + 20, 11, fill=c)
    add_text(s, bx + 104, by, 260, 40, filename,
             size=12, color=MUTED, font=d.font, anchor=MSO_ANCHOR.MIDDLE, line_spacing=1.0)
    for i in range(rows):
        ry = by + 66 + i * 46
        add_rect(s, bx + 28, ry, bw - 56, 30, fill=CARD_GRAY, radius=8)
        add_rect(s, bx + 44, ry + 11, 130 + (i % 3) * 90, 8, fill="D9DDE5", radius=4)
    tx = MX + bw + 44
    tw = W - MX - tx
    for i, b in enumerate(blocks[:3]):
        ty = by + i * 120
        add_circle(s, tx + 26, ty + 26, 52, fill=ICON_BG)
        add_glyph(s, tx + 26, ty + 26, b.get("glyph", "\u25c6"), size=22, color=PRIMARY, box=52)
        add_text(s, tx + 68, ty + 4, tw - 68, 26, b["heading"],
                 size=18, bold=True, color=HEADING, font=d.font, line_spacing=1.2)
        add_text(s, tx + 68, ty + 36, tw - 68, 72, b["text"],
                 size=14, color=BODY, font=d.font, line_spacing=1.45)
    return s


def wrapup(d, title, now, nxt, eyebrow="WRAP-UP"):
    """now/nxt: {glyph, heading, lines}"""
    return two_col(d, eyebrow, title, now, nxt)
