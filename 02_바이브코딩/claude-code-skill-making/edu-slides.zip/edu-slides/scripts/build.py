# -*- coding: utf-8 -*-
"""JSON 콘텐츠 명세 -> pptx.

사용:
    python build.py deck.json [-o out.pptx] [--font "Malgun Gothic"] [--pdf]

JSON 형식은 examples/sample-deck.json 참고.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import deck as D  # noqa: E402

SOFFICE = [
    r"C:\Program Files\LibreOffice\program\soffice.exe",
    r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    "soffice",
]


def render(d, spec):
    for i, sl in enumerate(spec["slides"]):
        t = sl.get("type")
        args = {k: v for k, v in sl.items() if k != "type"}
        try:
            if t == "cover":
                D.cover(d, **args)
            elif t == "two_col":
                D.two_col(d, **args)
            elif t == "terms":
                D.terms(d, **args)
            elif t == "step_overview":
                D.step_overview(d, **args)
            elif t == "step_detail":
                D.step_detail(d, **args)
            elif t == "checklist":
                D.checklist(d, **args)
            elif t == "preview":
                D.preview(d, **args)
            elif t == "wrapup":
                D.wrapup(d, **args)
            else:
                raise ValueError("알 수 없는 슬라이드 type: %r" % t)
        except TypeError as e:
            raise SystemExit("슬라이드 %d (type=%s) 인자 오류: %s" % (i + 1, t, e))


def to_pdf(pptx_path):
    outdir = os.path.dirname(os.path.abspath(pptx_path)) or "."
    for exe in SOFFICE:
        if exe != "soffice" and not os.path.exists(exe):
            continue
        try:
            subprocess.run([exe, "--headless", "--convert-to", "pdf",
                            "--outdir", outdir, os.path.abspath(pptx_path)],
                           check=True, capture_output=True, timeout=180)
            return os.path.splitext(pptx_path)[0] + ".pdf"
        except Exception:
            continue
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("-o", "--out")
    ap.add_argument("--font", help="강제 폰트 (기본: Pretendard > Malgun Gothic > Noto Sans KR 자동)")
    ap.add_argument("--pdf", action="store_true", help="LibreOffice 로 PDF 도 만든다 (검수용)")
    a = ap.parse_args()

    with open(a.spec, encoding="utf-8") as f:
        spec = json.load(f)

    d = D.Deck(spec.get("series", ""), spec.get("lecture", ""),
               font=a.font or spec.get("font"))
    render(d, spec)
    out = a.out or spec.get("output") or os.path.splitext(a.spec)[0] + ".pptx"
    d.save(out)
    print("saved: %s  (%d slides, font=%s)" % (out, len(d.slides), d.font))
    if a.pdf:
        p = to_pdf(out)
        print("pdf:   %s" % (p or "LibreOffice 없음 - 건너뜀"))


if __name__ == "__main__":
    main()
