---
name: edu-slides
description: 비개발자·입문자용 시리즈 교육 슬라이드(16:9 pptx)를 정해진 디자인 시스템으로 만든다. "수업 자료 PPT 만들어줘", "강의 슬라이드", "교육용 pptx", "표지·스텝·체크리스트 슬라이드" 같은 요청에 사용한다. 흰 배경 + 블루 포인트, 상단 네이비 바 / 하단 블루 바 / 우측 하단 페이지 번호 고정.
---

# 교육용 슬라이드 (edu-slides)

슬라이드 1장 = 메시지 1개. 글을 채우지 말고 여백을 남긴다.
디자인은 **코드에 고정돼 있다.** 색·크기·간격을 직접 지정하지 말고 템플릿 함수를 쓴다.
전체 지침은 `reference/design-spec.md`.

## 작업 순서

1. **콘텐츠부터 정한다.** 시리즈명·강의명(상단 바에 들어감)과 슬라이드별 메시지를 사용자에게 확인한다.
   상단 바 문구는 상수가 아니라 매번 받는 입력이다.
2. `examples/sample-deck.json` 을 복사해 JSON 명세를 쓴다.
3. 빌드한다. 검수용 PDF까지 같이 만든다:
   ```bash
   python "~/.claude/skills/edu-slides/scripts/build.py" deck.json -o 결과.pptx --pdf
   ```
4. **눈으로 확인한다.** 스크립트가 에러 없이 끝난 것은 "잘 나왔다"가 아니다.
   PDF를 이미지로 뽑아 직접 본다:
   ```bash
   python -c "import fitz; d=fitz.open('결과.pdf'); [p.get_pixmap(dpi=100).save('s%d.png'%(i+1)) for i,p in enumerate(d)]"
   ```
   특히 볼 것 — 한글 줄이 카드 밖으로 새는지, 하단 콜아웃이 우측 페이지 번호와 겹치는지.
   (LibreOffice 가 없으면 PDF 단계를 건너뛰고, 사용자에게 직접 열어보라고 말한다.)

## 슬라이드 타입

JSON `slides[]` 의 `type` 과 인자. 나머지 키는 그대로 함수 인자로 전달된다.

| type | 용도 | 필수 인자 |
|---|---|---|
| `cover` | 표지 | `title`, (`accent_word`, `subtitle`) |
| `two_col` | 오늘/다음 2단 비교 | `eyebrow`, `title`, `left`, `right` — 각 `{glyph, heading, lines[]}` |
| `terms` | 핵심 용어 2가지 | `title`, `items[2]` — `{glyph, term, define, analogy}` |
| `step_overview` | 전체 단계 요약 | `title`, `steps[≤4]`, (`current` 1-based 강조) |
| `step_detail` | STEP n 상세 | `step_no`, `title`, `items[2~3]`, (`callout`, `callout_kind`) |
| `preview` | 결과물 미리보기 | `title`, `blocks[3]` — `{glyph, heading, text}`, (`filename`, `rows`) |
| `checklist` | 보안·요약 2×2 | `title`, `items[4]` — `{glyph, heading, text}`, (`banner`, `banner_kind`) |
| `wrapup` | 마무리 + 예고 | `title`, `now`, `nxt` (two_col 과 같은 모양) |

`callout_kind` / `banner_kind`: `tip`(연블루 ✓) · `warn`(연노랑 ⚠) · `danger`(연빨강 🔒).

## 글 안의 강조

본문 문자열에서 `**이렇게**` = 굵게+블루, `!!이렇게!!` = 굵게+빨강.
**한 슬라이드에 강조는 한두 군데까지.** 색을 남발하면 지침 위반이다.

## 지켜지는 것 (건드리지 말 것)

- 상단 네이비 바(38px, 강의 정보) · 하단 블루 바(7px) · 우측 하단 `n / 전체` — 모든 장에 자동.
  페이지 번호는 전체 장수를 안 뒤 `Deck.save()` 에서 찍힌다.
- 좌우 여백 84px, 본문 폭 1112px. 본문 블록은 `center_y()` 로 위아래 여백을 맞춘다.
- 카드는 라운드 18px + `#E2E8F0` 테두리, **그림자 없음**(도형의 `<p:style>` 을 떼어 테마 그림자를 막는다).
- 하단 콜아웃 폭은 880px 로 제한 — 페이지 번호와 겹치지 않게.

## 글쓰기 규칙

- 짧고 친근한 존댓말(`~합니다`, `~하세요`).
- 불릿은 슬라이드당 3개 안팎, 한 항목은 한 줄을 넘기지 않게 다듬는다.
- 어려운 개념은 비유로 (`API = 식당 주문 카운터`, `API 키 = 신분증`).
- 정보 블록이 5개 이상이면 슬라이드를 나눈다.

## 폰트

`Pretendard` → `Malgun Gothic` → `Noto Sans KR` 순으로 **설치된 것을 자동 선택**한다
(사용자 폰트 폴더 `%LOCALAPPDATA%\Microsoft\Windows\Fonts` 도 본다).
강제 지정은 `--font "Malgun Gothic"`. 한글이 다른 폰트로 새지 않도록 latin/ea/cs 를 모두 지정한다.
발표할 PC에 폰트가 없으면 폴백되므로, 배포 대상 PC에 Pretendard 설치를 권한다.

## 직접 코드로 만들 때

JSON 으로 표현이 안 되는 특수 장표는 `scripts/deck.py` 를 직접 임포트한다.
그래도 `Deck.new_slide()` 로 슬라이드를 만들어야 공통 요소가 붙는다.

```python
import sys; sys.path.insert(0, r"C:\Users\colab\.claude\skills\edu-slides\scripts")
import deck as D
d = D.Deck("시리즈명", "강의명")
D.cover(d, title="제목", accent_word="강조어")
s = d.new_slide(); d.head(s, "STEP 1", "제목")   # 커스텀 장표
d.save("out.pptx")
```
